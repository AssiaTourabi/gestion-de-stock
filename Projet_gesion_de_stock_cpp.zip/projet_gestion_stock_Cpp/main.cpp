#include<iostream>
#include<string>
#include<cstring>
#include<vector>
#include<fstream>
#include<ctime>
using namespace std;


//     LA CLASSE MERE PRODUCT

// DECLARATION DE CLASSE

class product
{

protected:
    int itemcode;
    string itemname;
    float itemprice;
    int quantity;
public:
    //constructeurs
    product();
    product(int,string,float,int);
    //destructeurs
    ~product();
    //manipulations
    virtual void add_item()=0;
    virtual int search_item_code()=0;
    virtual void search_item_name()=0;
    virtual void search_item_price()=0;
    virtual void display();
    void delete_item();
    //getters
    int Get_itemcode();
    float Get_itemprice();
    string Get_itemname();
    int Get_quantity();
    //setters
    void Set_itemcode(int);
    void Set_itemprice(float);
    void Set_itemname(string);
    void Set_quantity(int);
};

// DEFINITION DES METHODES
// definition constructeurs
product::product()
{
    itemcode=0;
    itemname="NO NAME";
    itemprice=0;
    quantity=0;

}

product::product(int c,string n,float p,int q)
{
    itemcode=c;
    itemname=n;
    itemprice=p;
    quantity=q;
}

// definiton destructeur
product::~product() {}

// definition manipulations

void product::delete_item()
{
    delete this ;
}

void product::display()
{
    cout<<"\n le nom du produit est:"<<itemname<<endl;
    cout<<"\n le code du produit est:"<<itemcode<<endl;
    cout<<"\n le prix du produit est:"<<itemprice<<"DH"<<endl;

}

// definition getters

int product::Get_itemcode()
{
    return itemcode;
}

float product::Get_itemprice()
{
    return itemprice;
}

string product::Get_itemname()
{
    return itemname;
}
int product::Get_quantity()
{
    return quantity;
}
void product::Set_itemcode(int a)
{

    itemcode=a;
}
void product::Set_itemname(string a)
{
    itemname=a;
}
void product::Set_itemprice(float a)
{
    itemprice=a;
}
void product::Set_quantity(int a)
{
    quantity=a;
}

//         LA CLASSE FILLE PC

// DECLARATION DE LA CLASSE

class pc:public product
{

private:
    string processor;
    int RAM_CAPACITY;
    string OS;
    static int pc_counter;//le nombre de types de pcs

public:
    //constructeurs et destructeurs
    pc(int code,string name,float price,int quantity,string p,int RAM,string SE):product(code,name,price,quantity)
    {
        processor=p;
        RAM_CAPACITY=RAM;
        OS=SE;

    }
    pc():product()
    {
        processor="NO NAME";
        RAM_CAPACITY=0;
        OS="NO NAME";
    }
    ~pc() {}
    // manipulations
    void add_item();
    void delete_item();
    void display();
    int search_item_code();
    void search_item_name();
    void search_item_price();
    void search_item_processor();
    void search_item_RAM();
    void search_item_OS();

    //getters
    string Get_processor();
    int Get_RAM_CAPACITY();
    string Get_OS();

    //setters
    void Set_processor(string );
    void Set_RAM_CAPACITY(int );
    void Set_OS(string );

};

//initialisation du compteur

int pc::pc_counter=0;

//cr�ation d'un vecteur dont les elements sont des pcs

vector<pc> listepcs;

//  DEFINITON DES METHODES

// definition des manipulations

void pc::add_item()
{
    listepcs.push_back(*this);
    pc_counter++;
}

void pc::delete_item()
{
    product::delete_item();
    pc_counter--;
}


void pc::display()
{
    product::display();
    cout<<"\n Le processeur integr� dans ce produit est: "<<processor<<endl;
    cout<<"\n Le syst�me d\'exploitation utilis� pour ce produit est: "<<OS<<endl;
    cout<<"\n La capacit� RAM de ce produit est: "<<RAM_CAPACITY<<"GO"<<endl;
    cout<<"la quantit� de ce produit en stock est: "<<quantity<<"�lements"<<endl;
}

int pc::search_item_code()
{
    for(int i=0; i<listepcs.size(); i++)
    {
        if((listepcs[i].itemcode)==itemcode)
            return i;
    }
    return -1;
}

void pc::search_item_name()
{
    for(int i=0; i<listepcs.size(); i++)
    {
        if((itemname.compare(listepcs[i].itemname))==0)
            listepcs[i].pc::display();
    }
}
void pc::search_item_price()
{
    for(int i=0; i<listepcs.size(); i++)
    {
        if(itemprice==listepcs[i].itemprice)
            listepcs[i].pc::display();
    }
}


void pc::search_item_processor()
{
    for(int i=0; i<listepcs.size(); i++)
    {
        if((processor.compare(listepcs[i].processor))==0)
            listepcs[i].pc::display();
    }
}

void pc::search_item_RAM()
{
    for(int i=0; i<listepcs.size(); i++)
    {
        if(RAM_CAPACITY==listepcs[i].RAM_CAPACITY)
            listepcs[i].pc::display();
    }
}

void pc::search_item_OS()
{
    for(int i=0; i<listepcs.size(); i++)
    {
        if((OS.compare(listepcs[i].OS))==0)
            listepcs[i].pc::display();
    }
}

//definition getters

string pc::Get_processor()
{
    return processor;
}

int pc::Get_RAM_CAPACITY()
{
    return RAM_CAPACITY;
}

string pc::Get_OS()
{
    return OS;
}

//definition setters

void pc::Set_processor(string p)
{
    processor=p;
}

void pc::Set_RAM_CAPACITY(int r)
{
    RAM_CAPACITY=r;
}

void pc::Set_OS(string SE)
{
    OS=SE;
}

//         LA CLASSE FILLE TABLET

// DECLARATION DE LA CLASSE

class tablet:public product
{


private:
    float inch;
    string memory;
    static int tablet_counter;//le nombre de types de tablettes

public:
//constructeurs et destructeurs
    tablet():product()
    {
        inch=0;
        memory="NO NAME";

    }
    ~tablet() {}

    tablet( int cod,string nom,float prix,int quantity,float inch,string memory):product(cod,nom,prix,quantity)
    {
        this->inch=inch;
        this-> memory= memory;
    }
// manipulations
    void add_item();
    void delete_item();
    void display();
    int search_item_code();
    void search_item_name();
    void search_item_price();
    void search_item_inch();
    void search_item_memory();
//getters
    float get_inch();
    string get_memory();
//setters
    void set_inch(float );
    void set_memory(string );

};

//initialisation du compteur

int tablet::tablet_counter=0;

//cr�ation d'un vecteur dont les elements sont des tablettes

vector<tablet> listetabs;

//  DEFINITON DES METHODES

void tablet::add_item()
{
    listetabs.push_back(*this);
    tablet_counter++;
}
void tablet::delete_item()
{
    product::delete_item();
    tablet_counter--;
}



void tablet::display()
{
    product::display();
    cout<<"\n Le nombre de pouces de l\'ecran de cette tablette est:"<<inch<<endl;
    cout<<"\n :La capacite memoire de cette tablette est :"<<memory<<"GO"<<endl;

}

int tablet::search_item_code()
{
    for(int i=0; i<listetabs.size(); i++)
    {
        if((listetabs[i].itemcode)==itemcode)
            return i;
    }
    return -1;
}

void tablet::search_item_name()
{
    for(int i=0; i<listetabs.size(); i++)
    {
        if((itemname.compare(listetabs[i].itemname))==0)
            listetabs[i].tablet::display();
    }
}
void tablet::search_item_price()
{
    for(int i=0; i<listetabs.size(); i++)
    {
        if(itemprice==listetabs[i].itemprice)
            listetabs[i].tablet::display();
    }
}
void tablet::search_item_inch()
{
    for(int i=0; i<listetabs.size(); i++)
    {
        if(inch==listetabs[i].inch)
            listetabs[i].tablet::display();
    }
}
void tablet::search_item_memory()
{
    for(int i=0; i<listetabs.size(); i++)
    {
        if((memory.compare(listetabs[i].memory))==0)
            listetabs[i].tablet::display();
    }
}

//definition getters
float tablet::get_inch()
{
    return inch;
}
string tablet::get_memory()
{
    return memory;
}
//definition setters
void tablet::set_inch(float i)
{
    inch=i;
}
void  tablet::set_memory(string m)
{
    memory=m;
}
//         LA CLASSE FILLE Phone

// DECLARATION DE LA CLASSE

class phone:public product
{
private:
    string front_cam;//nombre de megapixels du front camera
    string back_cam;//nombre de megapixels du back camera
    static int phone_counter;//le nombre de types de Telephones

public:
//constructeurs et destructeurs
    phone():product()
    {
        front_cam="None";
        back_cam="None";

    }
    ~phone() {}

    phone(int cod,string nom,float prix,int quantity,string front_cam,string back_cam):product(cod,nom,prix,quantity)
    {
        this->front_cam=front_cam;
        this->back_cam= back_cam;

    }
// manipulations
    void add_item();
    void delete_item();
    void display();
    int search_item_code();
    void search_item_name();
    void search_item_price();
    void search_item_front_cam();
    void search_item_back_cam();
//getters
    string get_front_cam();
    string get_back_cam();
//setters
    void set_front_cam(string );
    void set_back_cam(string );

};


//initialisation du compteur

int phone::phone_counter=0;

//cr�ation d'un vecteur dont les elements sont des Telephones

vector<phone>listephones;

//  DEFINITON DES METHODES

void phone::add_item()
{
    listephones.push_back(*this);
    phone_counter++;
}
void phone::delete_item()
{
    product::delete_item();
    phone_counter--;
}



void phone::display()
{
    product::display();
    cout<<"\n Le nombre de megapixels du front camera:"<<front_cam<<"px"<<endl;
    cout<<"\n Le nombre de megapixels du back camera:"<<back_cam<<"px"<<endl;

}

int phone::search_item_code()
{
    for(int i=0; i<listephones.size(); i++)
    {
        if((listephones[i].itemcode)==itemcode)
            return i;
    }
    return -1;
}

void phone::search_item_name()
{
    for(int i=0; i<listephones.size(); i++)
    {
        if((itemname.compare(listephones[i].itemname))==0)
            listephones[i].phone::display();
    }
}
void phone::search_item_price()
{
    for(int i=0; i<listephones.size(); i++)
    {
        if(itemprice==listephones[i].itemprice)
            listephones[i].phone::display();
    }
}
void phone::search_item_back_cam()
{
    for(int i=0; i<listephones.size(); i++)
    {
        if(back_cam.compare(listephones[i].back_cam))
            listephones[i].phone::display();
    }
}
void phone::search_item_front_cam()
{
    for(int i=0; i<listephones.size(); i++)
    {
        if((front_cam.compare(listephones[i].front_cam))==0)
            listephones[i].phone::display();
    }
}

//definition getters
string  phone::get_front_cam()
{
    return front_cam;
}
string phone::get_back_cam()
{
    return back_cam;
}
//definition setters
void phone::set_front_cam(string a)
{
    front_cam=a;

}
void  phone::set_back_cam(string a)
{
    back_cam=a;
}
class BILL
{
    int ID_BILL;
    int buy_quant;

public:
    BILL(int a,int b)
    {
        ID_BILL=a;
        buy_quant=b;
    }

    void facture()
    {
        int somme=0;
        string nom_fichier;
        cout<<"veuillez entrer le nom du fichier suivi de de l'extension .txt"<<endl;
        cin>> nom_fichier;
        ofstream projetcpp;
        projetcpp.open(nom_fichier);
        projetcpp<<"\t GI ELECTRONICS"<<endl;
        projetcpp<<"-------------------------------------------------------------"<<endl;
        projetcpp<<ID_BILL<<endl;
        time_t tmm=time(0);
        char* dt=ctime(&tmm);
        projetcpp<<"\t"<<dt<<endl;
        projetcpp<<"\t PRODUITS ACHETEES"<<endl;
        projetcpp<<"-------------------------------------------------------------"<<endl;
        for(int i=0; i<buy_quant; i++)
        {
            cout<<"veuillez entrer le code du produit"<<endl;
            int n;
            cin>>n;
            pc p1;
            tablet p2;
            phone p3;
            string namebill;
            float pricebill;
            p1.Set_itemcode(n);
            int k=p1.search_item_code();
            if(k!=-1)
            {
                namebill=listepcs[k].Get_itemname();
                pricebill=listepcs[k].Get_itemprice();
            }
            else
            {
                p2.Set_itemcode(n);
                k=p2.search_item_code();
                if(k!=-1)
                {
                    namebill=listetabs[k].Get_itemname();
                    pricebill=listetabs[k].Get_itemprice();
                }
                else
                {
                    p3.Set_itemcode(n);
                    k=p3.search_item_code();
                    if (k!=-1)
                    {
                        namebill=listephones[k].Get_itemname();
                        pricebill=listephones[k].Get_itemprice();

                    }
                    else
                    {
                        cout<<"ce produit n'existe pas"<<endl;
                    }
                }
            }
            projetcpp<<namebill<<"\t";
            projetcpp<<pricebill<<"DH"<<endl;
            somme+=pricebill;

        }
        projetcpp<<"\t TOTAL"<<endl;
        projetcpp<<somme<<"DH"<<endl;
        projetcpp<<"-------------------------------------------------------------"<<endl;
        projetcpp<<"\t*MERCI DE VOTRE VISITE*\t"<<endl;
    }
};



// PARTIE FONCTIONNELLE

//AFFICHAGE DE LA LISTE DES PCS
void display_all_pcs()
{
    for(int i=0; i<listepcs.size(); i++)
    {
        listepcs[i].display();
    }
}

//AFFICHAGE DE LA LISTE DES TABLETTES
void display_all_tabs()
{
    for(int i=0; i<listetabs.size(); i++)
    {
        listetabs[i].display();
    }
}

//AFFICHAGE DE LA LISTE DES TELEPHONES

void display_all_phones()
{
    for(int i=0; i<listephones.size(); i++)
    {
        listephones[i].display();
    }
}

//LE MAX DE PRIX DES PCS

float max_price_pcs()
{
    float max=listepcs[0].Get_itemprice();
    for(int i=1; i<listepcs.size(); i++)
    {
        if(listepcs[i].Get_itemprice()>max)
        {
            max=listepcs[i].Get_itemprice();
        }
    }
    return max;
}

//LE MAX DE PRIX DES TABLETTES

float max_price_tabs()
{
    float max=listetabs[0].Get_itemprice();
    for(int i=1; i<listetabs.size(); i++)
    {
        if(listetabs[i].Get_itemprice()>max)
        {
            max=listetabs[i].Get_itemprice();
        }
    }
    return max;
}

//LE MAX DE PRIX DES TELEPHONES

float max_price_phones()
{
    float max=listephones[0].Get_itemprice();
    for(int i=1; i<listephones.size(); i++)
    {
        if(listephones[i].Get_itemprice()>max)
        {
            max=listephones[i].Get_itemprice();
        }
    }
    return max;
}


//LE MIN DE PRIX DES PCS

float min_price_pcs()
{
    float min=listepcs[0].Get_itemprice();
    for(int i=1; i<listepcs.size(); i++)
    {
        if(listepcs[i].Get_itemprice()<min)
        {
            min=listepcs[i].Get_itemprice();
        }
    }
    return min;
}

//LE MIN DE PRIX DES TABLETTES

float min_price_tabs()
{
    float min=listetabs[0].Get_itemprice();
    for(int i=1; i<listetabs.size(); i++)
    {
        if(listetabs[i].Get_itemprice()<min)
        {
            min=listetabs[i].Get_itemprice();
        }
    }
    return min;
}

//LE MIN DE PRIX DES TELEPHONES

float min_price_phones()
{
    float min=listephones[0].Get_itemprice();
    for(int i=1; i<listephones.size(); i++)
    {
        if(listephones[i].Get_itemprice()<min)
        {
            min=listephones[i].Get_itemprice();
        }
    }
    return min;
}

//MENU PRINCIPAL
void menu_principal()
{
    cout<<"*** menu principale ***"<<endl;
    cout<<"POUR LA GESTION DU STOCK   :TAPEZ 1"<<endl;
    cout<<"POUR LA FACTURATION        :TAPEZ 2"<<endl;
    cout<<"POUR QUITTER L'APPLICATION :TAPEZ 0"<<endl;
}
//MENU DE GESTION DE STOCK
void menu_gestion_stock()
{
    cout<<"*** menu gestion stock ***"<<endl;
    cout<<"POUR LA GESTION DES PCS        :TAPEZ 1"<<endl;
    cout<<"POUR LA GESTION DES TABLETTES  :TAPEZ 2"<<endl;
    cout<<"POUR LA GESTION DES TELEPHONES :TAPEZ 3"<<endl;
}
//MENU GESTION DES PCS
void menu_gestion_pcs()
{
    cout<<"*** menu gestion pcs ***"<<endl;
    cout<<"POUR AJOUTER UN NOUVEAU TYPE DE PCS AU STOCK    :TAPEZ 1"<<endl;
    cout<<"POUR SUPPRIMER DEFINITIVEMENT UN TYPE DE PCS    :TAPEZ 2"<<endl;
    cout<<"POUR AFFICHER LE PC LE MOINS CHER               :TAPEZ 3"<<endl;
    cout<<"POUR AFFICHER LE PC LE PLUS CHER                :TAPEZ 4"<<endl;
    cout<<"POUR AFFICHER TOUS LES PCS DISPONIBLES          :TAPEZ 5"<<endl;
    cout<<"POUR MODIFIER UNE CARACTERISTIQUE D'UN PC DONNE :TAPEZ 6"<<endl;
    cout<<"POUR RECHERCHER UN PC DONNE                     :TAPEZ 7"<<endl;
}

//MENU GESTION DES TABLETTES

void menu_gestion_tabs()
{
    cout<<"*** menu gestion tablettes ***"<<endl;
    cout<<"POUR AJOUTER UN NOUVEAU TYPE DE TABLETTES AU STOCK      :TAPEZ 1"<<endl;
    cout<<"POUR SUPPRIMER DEFINITIVEMENT UN TYPE DE TABLETTES      :TAPEZ 2"<<endl;;
    cout<<"POUR AFFICHER LA TABLETTE LA MOINS CHER                 :TAPEZ 3"<<endl;
    cout<<"POUR AFFICHER LA TABLETTE LA PLUS CHER                  :TAPEZ 4"<<endl;
    cout<<"POUR AFFICHER TOUTES LES TABLETTES DISPONIBLES          :TAPEZ 5"<<endl;
    cout<<"POUR MODIFIER UNE CARACTERISTIQUE D'UNE TABLETTE DONNEE :TAPEZ 6"<<endl;
    cout<<"POUR RECHERCHER UNE TABLETTE DONNEE                     :TAPEZ 7"<<endl;
}

//MENU GESTION DES TELEPHONES
void menu_gestion_phones()
{
    cout<<"*** menu gestion telephones ***"<<endl;
    cout<<"POUR AJOUTER UN NOUVEAU TYPE DE TELEPHONES AU STOCK      :TAPEZ 1"<<endl;
    cout<<"POUR SUPPRIMER DEFINITIVEMENT UN TYPE DE TELEPHONES      :TAPEZ 2"<<endl;
    cout<<"POUR AFFICHER LE TELEPHONE LE MOINS CHER                 :TAPEZ 3"<<endl;
    cout<<"POUR AFFICHER LA TELEPHONE LE PLUS CHER                  :TAPEZ 4"<<endl;
    cout<<"POUR AFFICHER TOUTS LES TELEPHONES DISPONIBLES           :TAPEZ 5"<<endl;
    cout<<"POUR MODIFIER UNE CARACTERISTIQUE D'UN TELEPHONE DONNE   :TAPEZ 6"<<endl;
    cout<<"POUR RECHERCHER UN TELEPHONE DONNE                       :TAPEZ 7"<<endl;
}

//MENU DE RECHERCHE  DE PCS
void menu_search_pc()
{
    cout<<"*** menu rechercher pc ***"<<endl;
    cout<<"POUR CHERCHER PAR CODE                           :TAPEZ 1"<<endl;
    cout<<"POUR CHERCHER PAR NOM                            :TAPEZ 2"<<endl;
    cout<<"POUR CHERCHER PAR PRIX                           :TAPEZ 3"<<endl;
    cout<<"POUR CHERCHER PAR TYPE DE PROCESSEUR             :TAPEZ 4"<<endl;
    cout<<"POUR CHERCHER PAR CAPACITE DE RAM                :TAPEZ 5"<<endl;
    cout<<"POUR CHERCHER PAR TYPE DE SYSTEME D'EXPLOITATION :TAPEZ 6"<<endl;
}
//MENU DE RECHERCHE DE TABLETTES
void menu_search_tab()
{
    cout<<"*** menu rechercher tabellete ***"<<endl;
    cout<<"POUR CHERCHER PAR CODE                           :TAPEZ 1"<<endl;
    cout<<"POUR CHERCHER PAR NOM                            :TAPEZ 2"<<endl;
    cout<<"POUR CHERCHER PAR PRIX                           :TAPEZ 3"<<endl;
    cout<<"POUR CHERCHER PAR NOMBRE DE POUCES DE L'ECRAN    :TAPEZ 4"<<endl;
    cout<<"POUR CHERCHER PAR CAPACITE MEMOIRE               :TAPEZ 5"<<endl;
}
//MENU DE RECHERCHE DE TELEPHONES
void menu_search_phone()
{
    cout<<"*** menu rechercher telephones ***"<<endl;
    cout<<"POUR CHERCHER PAR CODE                             :TAPEZ 1"<<endl;
    cout<<"POUR CHERCHER PAR NOM                              :TAPEZ 2"<<endl;
    cout<<"POUR CHERCHER PAR PRIX                             :TAPEZ 3"<<endl;
    cout<<"POUR CHERCHER PAR PRECISION DE CAMERA DU DEVANT    :TAPEZ 4"<<endl;
    cout<<"POUR CHERCHER PAR PRECISION DE CAMERA DU DERRIERE  :TAPEZ 5"<<endl;
}
//MENU DE MODIFICATION  DE PCS
void menu_modify_pc()
{
    cout<<"*** menu modifier pc ***"<<endl;
    cout<<"POUR MODIFIER LE CODE                           :TAPEZ 1"<<endl;
    cout<<"POUR MODIFIER LE NOM                            :TAPEZ 2"<<endl;
    cout<<"POUR MODIFIER LE PRIX                           :TAPEZ 3"<<endl;
    cout<<"POUR MODIFIER LA QUANTITE                       :TAPEZ 4"<<endl;
    cout<<"POUR MODIFIER LE TYPE DE PROCESSEUR             :TAPEZ 5"<<endl;
    cout<<"POUR MODIFIER LA  CAPACITE DE RAM               :TAPEZ 6"<<endl;
    cout<<"POUR MODIFIER LE TYPE DE SYSTEME D'EXPLOITATION :TAPEZ 7"<<endl;
}

//MENU DE MODIFICATION  DE TABLETTES
void menu_modify_tab()
{
    cout<<"*** menu modifier tabellete ***"<<endl;
    cout<<"POUR MODIFIER LE CODE                           :TAPEZ 1"<<endl;
    cout<<"POUR MODIFIER LE NOM                            :TAPEZ 2"<<endl;
    cout<<"POUR MODIFIER LE PRIX                           :TAPEZ 3"<<endl;
    cout<<"POUR MODIFIER LA QUANTITE                       :TAPEZ 4"<<endl;
    cout<<"POUR MODIFIER LE NOMBRE DE POUCES DE L'ECRAN    :TAPEZ 5"<<endl;
    cout<<"POUR MODIFIER LE CAPACITE MEMOIRE               :TAPEZ 6"<<endl;
}

//MENU DE MODIFICATION  DE TELEPHONES
void menu_modify_phone()
{
    cout<<"*** menu modifier telephones ***"<<endl;
    cout<<"POUR MODIFIER LE CODE                             :TAPEZ 1"<<endl;
    cout<<"POUR MODIFIER LE NOM                              :TAPEZ 2"<<endl;
    cout<<"POUR MODIFIER LE PRIX                             :TAPEZ 3"<<endl;
    cout<<"POUR MODIFIER LA QUANTITE                         :TAPEZ 4"<<endl;
    cout<<"POUR MODIFIER LA PRECISION DE CAMERA DU DEVANT    :TAPEZ 5"<<endl;
    cout<<"POUR MODIFIER LA PRECISION DE CAMERA DU DERRIERE  :TAPEZ 6"<<endl;
}

int main()
{
    int menu;
    int gestion_stock;
    int gestion_pc;
    float prixpc;
    int supprimer;
    int codepc;
    string nompc;
    int rampc;
    string processeurpc;
    string ospc;
    int quantitepc;
    do
    {
        menu_principal() ;
        cin>>menu;
        //SWITCH
        switch(menu)
        {
        case 1:
            menu_gestion_stock();
            cin>>gestion_stock;
            switch(gestion_stock)
            {
            case 1:
            {

                menu_gestion_pcs();
                cin>>gestion_pc;
                switch(gestion_pc)
                {
                case 1:
                {
                    cout<<"Veuillez entrez les caract�ristiques du pc que vous souhaitez ajouter"<<endl;
                    cout<<"Entrez le nom du pc"<<endl;
                    cin>>nompc;
                    cout<<"Entrez le code du pc"<<endl;
                    cin>>codepc;
                    cout<<"Entrez la capacite RAM du pc"<<endl;
                    cin>>rampc;
                    cout<<" Entrez le type du processeur du pc"<<endl;
                    cin>>processeurpc;
                    cout<<"Entrez le type du systeme d'exploitation du pc"<<endl;
                    cin>>ospc;
                    cout<<"Entrez la quantite du pc"<<endl;
                    cin>>quantitepc;
                    cout<<"Entrez le prix du pc"<<endl;
                    cin>>prixpc;
                    pc pc1(codepc,nompc,prixpc,quantitepc,processeurpc,rampc,ospc);
                    pc1.add_item();
                    break;
                }
                case 2:
                {
                    cout<<"veuillez entrer le code du pc que vous voulez supprimer"<<endl;
                    cin>>supprimer;
                    pc pc2;
                    pc2.Set_itemcode(supprimer);
                    listepcs[pc2.search_item_code()].delete_item();
                    break;
                }
                case 3:
                {
                    pc pc3;
                    pc3.Set_itemprice(min_price_pcs());
                    pc3.search_item_price();
                    break;
                }
                case 4:
                {
                    pc pc4;
                    pc4.Set_itemprice(max_price_pcs());
                    pc4.search_item_price();
                    break;
                }
                case 5:
                    display_all_pcs();
                    break;
                case 6:
                {
                    int menumodifierpc;
                    menu_modify_pc();
                    cin>>menumodifierpc;
                    switch(menumodifierpc)
                    {
                    case 1:
                    {
                        cout<<"Entrez l\'ancier code"<<endl;
                        int codepcmodifier1;
                        cin>>codepcmodifier1;
                        pc pc5;
                        pc5.Set_itemcode(codepcmodifier1);
                        cout<<"Entrez le nouveau code"<<endl;
                        int codepcmodifier2;
                        cin>>codepcmodifier2;
                        listepcs[pc5.search_item_code()].Set_itemcode(codepcmodifier2);
                        break;
                    }
                    case 2:
                    {
                        cout<<"Entrez le code de l\'article"<<endl;
                        int codepcmodifier3;
                        cin>>codepcmodifier3;
                        pc pc6;
                        pc6.Set_itemcode(codepcmodifier3);
                        cout<<"Entrez le nouveau nom"<<endl;
                        string nouveaunompc;
                        cin>>nouveaunompc;
                        listepcs[pc6.search_item_code()].Set_itemname(nouveaunompc);
                        break;
                    }
                    case 3:
                    {
                        cout<<"Entrez le code de l\'article"<<endl;
                        int codepcmodifier4;
                        cin>>codepcmodifier4;
                        pc pc7;
                        pc7.Set_itemcode(codepcmodifier4);
                        cout<<"Entrez le nouveau prix"<<endl;
                        float nouveauprixpc;
                        cin>>nouveauprixpc;
                        listepcs[pc7.search_item_code()].Set_itemprice(nouveauprixpc);
                        break;
                    }
                    case 4:
                    {
                        cout<<"Entrez le code de l\'article"<<endl;
                        int codepcmodifier5;
                        cin>>codepcmodifier5;
                        pc pc8;
                        pc8.Set_itemcode(codepcmodifier5);
                        cout<<"Entrez la nouvelle quantite"<<endl;
                        int nouvellequantitepc;
                        cin>>nouvellequantitepc;
                        listepcs[pc8.search_item_code()].Set_itemprice(listepcs[pc8.search_item_code()].Get_quantity()+nouvellequantitepc);
                        break;
                    }
                    case 5:
                    {
                        cout<<"Entrez le code de l\'article"<<endl;
                        int codepcmodifier6;
                        cin>>codepcmodifier6;
                        pc pc9;
                        pc9.Set_itemcode(codepcmodifier6);
                        cout<<"Entrez le nouveau type de processeur"<<endl;
                        string nouveautypepc;
                        cin>>nouveautypepc;
                        listepcs[pc9.search_item_code()].Set_processor(nouveautypepc);
                        break;
                    }
                    case 6:
                    {
                        cout<<"Entrez l\'ancier code"<<endl;
                        int codepcmodifier7;
                        cin>>codepcmodifier7;
                        pc pc10;
                        pc10.Set_itemcode(codepcmodifier7);
                        cout<<"Entrez la nouvelle capacite RAM"<<endl;
                        int nouvellecaprampc;
                        cin>>nouvellecaprampc;
                        listepcs[pc10.search_item_code()].Set_RAM_CAPACITY(nouvellecaprampc);
                        break;
                    }
                    case 7:
                    {
                        cout<<"Entrez le code de l\'article"<<endl;
                        int codepcmodifier8;
                        cin>>codepcmodifier8;
                        pc pc11;
                        pc11.Set_itemcode(codepcmodifier8);
                        cout<<"Entrez le nouveau systeme d\'exploitation"<<endl;
                        string nouveautypeOSpc;
                        cin>>nouveautypeOSpc;
                        listepcs[pc11.search_item_code()].Set_processor(nouveautypeOSpc);
                        break;
                    }
                    }
                    break;
                }
                case 7:
                {
                    int menurechercherpc;
                    menu_search_pc();
                    cin>>menurechercherpc;
                    switch(menurechercherpc)
                    {
                    case 1:
                    {
                        int codsearchpc;
                        cout<<"entrez le code de l\'article que vous voulez chercher"<<endl;
                        cin>>codsearchpc;
                        pc pc12;
                        pc12.Set_itemcode(codsearchpc);
                        int indice=pc12.search_item_code();
                        if(indice==-1)
                        {
                            cout<<"Cet article n\'existe pas"<<endl;
                        }
                        else
                            listepcs[indice].display();
                        break;
                    }
                    case 2:
                    {
                        string namesearchpc;
                        cout<<"entrez le nom de l\'article que vous voulez chercher"<<endl;
                        cin>>namesearchpc;
                        pc pc13;
                        pc13.Set_itemname(namesearchpc);
                        pc13.search_item_name();
                        break;
                    }
                    case 3:
                    {
                        float pricesearchpc;
                        cout<<"entrez le prix de l\'article que vous voulez chercher"<<endl;
                        cin>>pricesearchpc;
                        pc pc14;
                        pc14.Set_itemprice(pricesearchpc);
                        pc14.search_item_price();
                        break;
                    }
                    case 4:
                    {
                        string processorsearchpc;
                        cout<<"entrez le processeur de l\'article que vous voulez chercher"<<endl;
                        cin>>processorsearchpc;
                        pc pc15;
                        pc15.Set_processor(processorsearchpc);
                        pc15.search_item_processor();
                        break;
                    }
                    case 5:
                    {
                        int RAMsearchpc;
                        cout<<"entrez la capacite RAM de l\'article que vous voulez chercher"<<endl;
                        cin>>RAMsearchpc;
                        pc pc16;
                        pc16.Set_RAM_CAPACITY(RAMsearchpc);
                        pc16.search_item_RAM();
                        break;
                    }
                    case 6:
                    {
                        string OSsearchpc;
                        cout<<"entrez le SE de l\'article que vous voulez chercher"<<endl;
                        cin>>OSsearchpc;
                        pc pc17;
                        pc17.Set_OS(OSsearchpc);
                        pc17.search_item_OS();
                        break;
                    }
                    }

                }
                }
                break;
            }
            case 2:
            {
                menu_gestion_tabs();
                int gestion_tabs;
                cin>>gestion_tabs;
                switch(gestion_tabs)
                {
                case 1:
                {
                    cout<<"Veuillez entrez les caract�ristiques du type de tablette que vous souhaitez ajouter"<<endl;
                    cout<<"Entrez le nom de la tablette"<<endl;
                    string nomtab;
                    cin>>nomtab;
                    cout<<"Entrez le code de la tablette"<<endl;
                    int codetab;
                    cin>>codetab;
                    cout<<"Entrez le nombre de pouce de l\'ecran de la tablette"<<endl;
                    float inchtab;
                    cin>>inchtab;
                    cout<<" Entrez la capacite memoire de la tablette"<<endl;
                    string memtab;
                    cin>>memtab;
                    cout<<"Entrez la quantite  de la tablette"<<endl;
                    int quantitetab;
                    cin>>quantitetab;
                    cout<<"Entrez le prix de la tablette"<<endl;
                    float prixtab;
                    cin>>prixtab;
                    tablet tab1(codetab,nomtab,prixtab,quantitetab,inchtab,memtab);
                    tab1.add_item();
                    break;
                }
                case 2:
                {
                    cout<<"veuillez entrer le code de la tablette que vous voulez supprimer"<<endl;
                    int supprimertab;
                    cin>>supprimertab;
                    tablet tab2;
                    tab2.Set_itemcode(supprimertab);
                    listetabs[tab2.search_item_code()].delete_item();
                    break;
                }
                case 3:
                {
                    tablet tab3;
                    tab3.Set_itemprice(min_price_tabs());
                    tab3.search_item_price();
                    break;
                }
                case 4:
                {
                    tablet tab4;
                    tab4.Set_itemprice(max_price_tabs());
                    tab4.search_item_price();
                    break;
                }
                case 5:
                    display_all_tabs();
                    break;
                case 6:
                {
                    int menumodifiertab;
                    menu_modify_tab();
                    cin>>menumodifiertab;
                    switch(menumodifiertab)
                    {
                    case 1:
                    {
                        cout<<"Entrez l\'ancier code"<<endl;
                        int codetabmodifier1;
                        cin>>codetabmodifier1;
                        tablet tab5;
                        tab5.Set_itemcode(codetabmodifier1);
                        cout<<"Entrez le nouveau code"<<endl;
                        int codetabmodifier2;
                        cin>>codetabmodifier2;
                        listetabs[tab5.search_item_code()].Set_itemcode(codetabmodifier2);
                        break;
                    }
                    case 2:
                    {
                        cout<<"Entrez le code de l\'article"<<endl;
                        int codetabmodifier3;
                        cin>>codetabmodifier3;
                        tablet tab6;
                        tab6.Set_itemcode(codetabmodifier3);
                        cout<<"Entrez le nouveau nom"<<endl;
                        string nouveaunomtab;
                        cin>>nouveaunomtab;
                        listetabs[tab6.search_item_code()].Set_itemname(nouveaunomtab);
                        break;
                    }
                    case 3:
                    {
                        cout<<"Entrez le code de l\'article"<<endl;
                        int codetabmodifier4;
                        cin>>codetabmodifier4;
                        tablet tab7;
                        tab7.Set_itemcode(codetabmodifier4);
                        cout<<"Entrez le nouveau prix"<<endl;
                        float nouveauprixtab;
                        cin>>nouveauprixtab;
                        listetabs[tab7.search_item_code()].Set_itemprice(nouveauprixtab);
                        break;
                    }
                    case 4:
                    {
                        cout<<"Entrez le code de l\'article"<<endl;
                        int codetabmodifier5;
                        cin>>codetabmodifier5;
                        tablet tab8;
                        tab8.Set_itemcode(codetabmodifier5);
                        cout<<"Entrez la nouvelle quantite"<<endl;
                        int nouvellequantitetab;
                        cin>>nouvellequantitetab;
                        listetabs[tab8.search_item_code()].Set_itemprice(listetabs[tab8.search_item_code()].Get_quantity()+nouvellequantitetab);
                        break;
                    }
                    case 5:
                    {
                        cout<<"Entrez le code de l\'article"<<endl;
                        int codetabmodifier6;
                        cin>>codetabmodifier6;
                        tablet tab9;
                        tab9.Set_itemcode(codetabmodifier6);
                        cout<<"Entrez la nouvelle valeur "<<endl;
                        float nouveauinchtab;
                        cin>>nouveauinchtab;
                        listetabs[tab9.search_item_code()].set_inch(nouveauinchtab);
                        break;
                    }
                    case 6:
                    {
                        cout<<"Entrez l\'ancier code"<<endl;
                        int codetabmodifier7;
                        cin>>codetabmodifier7;
                        tablet tab10;
                        tab10.Set_itemcode(codetabmodifier7);
                        cout<<"Entrez la nouvelle capacite memoire"<<endl;
                        string nouvellecapmemtab;
                        cin>>nouvellecapmemtab;
                        listetabs[tab10.search_item_code()].set_memory(nouvellecapmemtab);
                        break;
                    }
                    }
                }
                case 7:
                {
                    int menurecherchertab;
                    menu_search_tab();
                    cin>>menurecherchertab;
                    switch(menurecherchertab)
                    {
                    case 1:
                    {
                        int codsearchtab;
                        cout<<"entrez le code de l\'article que vous voulez chercher"<<endl;
                        cin>>codsearchtab;
                        tablet tab12;
                        tab12.Set_itemcode(codsearchtab);
                        int indice=tab12.search_item_code();
                        if(indice==-1)
                        {
                            cout<<"Cet article n\'existe pas"<<endl;
                        }
                        else
                            listetabs[indice].display();
                        break;
                    }
                    case 2:
                    {
                        string namesearchtab;
                        cout<<"entrez le nom de l\'article que vous voulez chercher"<<endl;
                        cin>>namesearchtab;
                        tablet tab13;
                        tab13.Set_itemname(namesearchtab);
                        tab13.search_item_name();
                        break;
                    }
                    case 3:
                    {
                        float pricesearchtab;
                        cout<<"entrez le prix de l\'article que vous voulez chercher"<<endl;
                        cin>>pricesearchtab;
                        tablet tab14;
                        tab14.Set_itemprice(pricesearchtab);
                        tab14.search_item_price();
                        break;
                    }
                    case 4:
                    {
                        float inchsearchtab;
                        cout<<"entrez le processeur de l\'article que vous voulez chercher"<<endl;
                        string processorsearchpc;
                        cin>>processorsearchpc;
                        pc pc15;
                        pc15.Set_processor(processorsearchpc);
                        pc15.search_item_processor();
                        break;
                    }
                    case 5:
                    {
                        string memsearchtab;
                        cout<<"entrez la capacite memoire de l\'article que vous voulez chercher"<<endl;
                        cin>>memsearchtab;
                        tablet tab16;
                        tab16.set_memory(memsearchtab);
                        tab16.search_item_memory();
                        break;
                    }

                    }
                }
                }
                break;
            }
            case 3:
            {
                menu_gestion_phones();
                int gestion_phones;
                cin>>gestion_phones;
                switch(gestion_phones)
                {
                case 1:
                {
                    cout<<"Veuillez entrez les caract�ristiques du type du telephone que vous souhaitez ajouter"<<endl;
                    cout<<"Entrez le nom du telephone"<<endl;
                    string nomphone;
                    cin>>nomphone;
                    cout<<"Entrez le code du telephone"<<endl;
                    int codephone;
                    cin>>codephone;
                    cout<<"Entrez le nombre de megapixels de le camera du devant"<<endl;
                    string frontcamtel;
                    cin>>frontcamtel;
                    cout<<" Entrez le nombre de megapixels de le camera du derriere"<<endl;
                    string backcamtel;
                    cin>>backcamtel;
                    cout<<"Entrez la quantite  du telephone"<<endl;
                    int quantitephone;
                    cin>>quantitephone;
                    cout<<"Entrez le prix du telephone"<<endl;
                    float prixphone;
                    cin>>prixphone;
                    phone tel1(codephone,nomphone,prixphone,quantitephone,frontcamtel,backcamtel);
                    tel1.add_item();
                    break;
                }
                case 2:
                {
                    cout<<"veuillez entrer le code du telephone que vous voulez supprimer"<<endl;
                    int supprimertel;
                    cin>>supprimertel;
                    phone tel2;
                    tel2.Set_itemcode(supprimertel);
                    listephones[tel2.search_item_code()].delete_item();
                    break;
                }
                case 3:
                {
                    phone tel3;
                    tel3.Set_itemprice(min_price_phones());
                    tel3.search_item_price();
                    break;
                }
                case 4:
                {
                    phone tel4;
                    tel4.Set_itemprice(max_price_phones());
                    tel4.search_item_price();
                    break;
                }
                case 5:
                    display_all_phones();
                    break;
                case 6:
                {
                    int menumodifierphone;
                    menu_modify_phone();
                    cin>>menumodifierphone;
                    switch(menumodifierphone)
                    {
                    case 1:
                    {
                        cout<<"Entrez l\'ancier code"<<endl;
                        int codetelmodifier1;
                        cin>>codetelmodifier1;
                        phone tel5;
                        tel5.Set_itemcode(codetelmodifier1);
                        cout<<"Entrez le nouveau code"<<endl;
                        int codetelmodifier2;
                        cin>>codetelmodifier2;
                        listephones[tel5.search_item_code()].Set_itemcode(codetelmodifier2);
                        break;
                    }
                    case 2:
                    {
                        cout<<"Entrez le code de l\'article"<<endl;
                        int codetelmodifier3;
                        cin>>codetelmodifier3;
                        phone tel6;
                        tel6.Set_itemcode(codetelmodifier3);
                        cout<<"Entrez le nouveau nom"<<endl;
                        string nouveaunomtel;
                        cin>>nouveaunomtel;
                        listephones[tel6.search_item_code()].Set_itemname(nouveaunomtel);
                        break;
                    }
                    case 3:
                    {
                        cout<<"Entrez le code de l\'article"<<endl;
                        int codetelmodifier4;
                        cin>>codetelmodifier4;
                        phone tel7;
                        tel7.Set_itemcode(codetelmodifier4);
                        cout<<"Entrez le nouveau prix"<<endl;
                        float nouveauprixtel;
                        cin>>nouveauprixtel;
                        listephones[tel7.search_item_code()].Set_itemprice(nouveauprixtel);
                        break;
                    }
                    case 4:
                    {
                        cout<<"Entrez le code de l\'article"<<endl;
                        int codetelmodifier5;
                        cin>>codetelmodifier5;
                        phone tel8;
                        tel8.Set_itemcode(codetelmodifier5);
                        cout<<"Entrez la nouvelle quantite"<<endl;
                        int nouvellequantitetel;
                        cin>>nouvellequantitetel;
                        listephones[tel8.search_item_code()].Set_itemprice(listephones[tel8.search_item_code()].Get_quantity()+nouvellequantitetel);
                        break;
                    }
                    case 5:
                    {
                        cout<<"Entrez le code de l\'article"<<endl;
                        int codetelmodifier6;
                        cin>>codetelmodifier6;
                        phone tel9;
                        tel9.Set_itemcode(codetelmodifier6);
                        cout<<"Entrez la nouvelle valeur "<<endl;
                        string nouveaufcamtel;
                        cin>>nouveaufcamtel;
                        listephones[tel9.search_item_code()].set_front_cam(nouveaufcamtel);
                        break;
                    }
                    case 6:
                    {
                        cout<<"Entrez l\'ancier code"<<endl;
                        int codetelmodifier7;
                        cin>>codetelmodifier7;
                        phone tel10;
                        tel10.Set_itemcode(codetelmodifier7);
                        cout<<"Entrez la nouvelle valeur"<<endl;
                        string nouveaubcamtel;
                        cin>>nouveaubcamtel;
                        listephones[tel10.search_item_code()].set_back_cam(nouveaubcamtel);
                        break;
                    }
                    }
                }
                case 7:
                {
                    int menurecherchertel;
                    menu_search_phone();
                    cin>>menurecherchertel;
                    switch(menurecherchertel)
                    {
                    case 1:
                    {
                        int codsearchtel;
                        cout<<"entrez le code de l\'article que vous voulez chercher"<<endl;
                        cin>>codsearchtel;
                        phone tel12;
                        tel12.Set_itemcode(codsearchtel);
                        int indice=tel12.search_item_code();
                        if(indice==-1)
                        {
                            cout<<"Cet article n\'existe pas"<<endl;
                        }
                        else
                            listephones[indice].display();
                        break;
                    }
                    case 2:
                    {
                        string namesearchtel;
                        cout<<"entrez le nom de l\'article que vous voulez chercher"<<endl;
                        cin>>namesearchtel;
                        phone tel13;
                        tel13.Set_itemname(namesearchtel);
                        tel13.search_item_name();
                        break;
                    }
                    case 3:
                    {
                        float pricesearchtel;
                        cout<<"entrez le prix de l\'article que vous voulez chercher"<<endl;
                        cin>>pricesearchtel;
                        phone tel14;
                        tel14.Set_itemprice(pricesearchtel);
                        tel14.search_item_price();
                        break;
                    }
                    case 4:
                    {
                        string fcamsearchtel;
                        cout<<"entrez la precision de la camera du devant de  l\'article que vous voulez chercher"<<endl;
                        cin>>fcamsearchtel;
                        phone tel15;
                        tel15.set_front_cam(fcamsearchtel);
                        tel15.search_item_front_cam();
                        break;
                    }
                    case 5:
                    {
                        string bcamsearchtel;
                        cout<<"entrez la precision de la camera du derriere de l\'article que vous voulez chercher"<<endl;
                        cin>>bcamsearchtel;
                        phone tel16;
                        tel16.set_back_cam(bcamsearchtel);
                        tel16.search_item_back_cam();
                        break;
                    }

                    }
                }
                }
                break;
            }

            }
            break;
        case 2:
        {
            cout<<"veuillez entrer un nouveau code pour la facture"<<endl;
            int codefactureclient;
            cin>>codefactureclient;
            cout<<"veuillez entrer la quantite d'articles achetes par le client"<<endl;
            int quantiteachclient;
            cin>>quantiteachclient;
            BILL A(codefactureclient,quantiteachclient);
            A.facture();
            break;
        }
        }
    }
    while(menu!=0);
    cout<<">>>>>>>> MERCI D\'AVOIR UTILISER CETTE APPLICATION <<<<<<<< "<<endl;

    return 0;
}
